using UnityEngine;
using UnityEngine.UI;
using System;
using TMPro;

public class DeckUI : MonoBehaviour
{
    public Image deckImage;
    public TextMeshProUGUI countText;
    void Start()
    {
        if (EventManager.Instance != null)
        {
            EventManager.Instance.OnUIUpdateRequired += UpdateTopCardVisual;
        }
        UpdateTopCardVisual();
    }
    // 덱 비주얼 업데이트
    public void UpdateTopCardVisual()
    {
        CardInstance top = DeckManager.Instance.PeekTop(1);
        if (top == null)
        {
            deckImage.enabled = false;
            countText.text = "0";
            return;
        }
        deckImage.enabled = true;
        deckImage.sprite = top.origin.backSprite;

        countText.text = DeckManager.Instance.MainDeck.Count.ToString();
    }
    // 덱 클릭시 뽑기
    public void OnClickDraw()
    {
        // 현재 턴인 플레이어를 가져와서 드로우 시킵니다.
        // TurnManager에 CurrentPlayer가 있음.
        PlayerData currentPlayer = TurnManager.Instance.CurrentPlayer;
        if (currentPlayer != null && currentPlayer.actionPoint > 0)
        {
            TurnManager.Instance.PlayerAction(currentPlayer, ActionType.DrawCard, null);
        }
        // todo if문으로 행동권 체크하고 행동권 제거
    }
}
