using UnityEngine;
using UnityEngine.UI;
using TMPro;
using UnityEngine.EventSystems;
public class PlayerUI : MonoBehaviour, IPointerClickHandler
{
    [Header("Common UI")]
    [SerializeField] protected TextMeshProUGUI nameText;
    [SerializeField] protected TextMeshProUGUI lifeText;
    [SerializeField] protected TextMeshProUGUI actionText;

    [SerializeField] private Image selectHighlightImage;
    private Image bgImage;
    private PlayerData data;
    public PlayerData Data => data;
    private bool isSelectable = false;
    [SerializeField] private Transform handZone;
    [SerializeField] private Transform keepZone;
    [SerializeField] private Transform trickZone;
    [SerializeField] private Transform passiveZone;

    // 컴퍼넌트 캐싱
    protected virtual void Awake()
    {
        bgImage = GetComponent<Image>();
        SetHighlight(false);
    }

    public virtual void Setup(PlayerData playerData)
    {
        data = playerData;
        EventManager.Instance.OnUIUpdateRequired += Refresh;
    }
    // 화면 갱신
    public virtual void Refresh()
    {
        if (data == null) return;
        if (nameText != null) 
            nameText.text = data.playerName;
        if (lifeText != null) 
            lifeText.text = $"Life : {data.life}";
        if (actionText != null) 
            actionText.text = $"AP : {data.actionPoint}";
    }
    public void SetSelectable(bool value)
    {
        isSelectable = value;
        SetSelectHighlight(value);
    }

    // 플레이어 UI를 클릭하면 게임 인풋매니저에 전달된다.
    public void OnPointerClick(PointerEventData eventData)
    {
        if (!isSelectable)
            return;
        GameInputManager.Instance.TrySelectPlayer(Data);
    }

    // 시각적 피드백(하이라이트)
    public virtual void SetHighlight(bool value)
    {
        if (bgImage != null)
        bgImage.color = value ? Color.yellow : Color.gray;
    }
    // 선택 가능 표시 (별도 레이어)
    protected virtual void SetSelectHighlight(bool value)
    {
        if (selectHighlightImage != null)
            selectHighlightImage.gameObject.SetActive(value);
    }
    // 메모리 관리 및 해제(이벤트 구독 해제)
    protected virtual void OnDestroy()
    {
        if (GameInputManager.Instance != null)
        {
            GameInputManager.Instance.UnregisterPlayerUI(this);
        }
        if (EventManager.Instance != null)
        {
            EventManager.Instance.OnUIUpdateRequired -= Refresh;
        }
    }
    public virtual Transform GetZone(CardZone zone)
    {
        switch (zone)
        {
            case CardZone.Hand: return handZone;
            case CardZone.Keep: return keepZone;
            case CardZone.Trick: return trickZone;
            case CardZone.Passive: return passiveZone;
        }
        return null;
    }
}
