using UnityEngine;

public static class ActionProcessor
{
    public static bool Execute(PlayerData user, ActionType action, CardInstance instance = null, PlayerData target = null)
    {
        if (user == null || user.actionPoint <= 0) return false;
        bool success = false;

        switch (action)
        {
            case ActionType.UseCard:
                success = ProcessUseCard(user, instance, target);
                break;
            case ActionType.StackAttack:
                success = ProcessStackAttack(user, instance, target);
                break;
            case ActionType.PlaceKeep:
                success = ProcessPlaceKeep(user, target, instance);
                break;
            case ActionType.PlaceTrick:
                success = ProcessPlaceTrick(user, instance);
                break;
            case ActionType.OpenTrick:
                success = ProcessOpenTrick(user, instance);
                break;
            case ActionType.DrawCard:
                user.DrawCard();
                success = true;
                break;
            case ActionType.OpenPassive:
                success = ProcessOpenPassive(user);
                break;
        }

        if (success)
        {
            user.UseActionPoint();
            EventManager.Instance.TriggerUIUpdate();
        }

        return success;
    }

    private static bool ProcessUseCard(PlayerData user, CardInstance instance, PlayerData target)
    {
        if (instance == null || !instance.CanUse()) return false;
        user.RemoveCardFromHand(instance);
        instance.ExecuteImmediateEffects(target);
        Debug.Log($"{user.playerName}가 카드를 사용했습니다.");
        return true;
    }

    private static bool ProcessStackAttack(PlayerData user, CardInstance instance, PlayerData target)
    {
        if (instance == null || !instance.CanStack()) return false;
        bool played = StackManager.Instance.PlayStackCard(instance);
        if (played)
        {
            user.RemoveCardFromHand(instance);
            instance.ExecuteImmediateEffects(target);
            Debug.Log($"{user.playerName}가 스택 공격을 수행했습니다.");
        }
        return played;
    }

    private static bool ProcessPlaceKeep(PlayerData user, PlayerData target, CardInstance instance)
    {
        if (target == null || instance == null || !instance.CanKeep()) return false;
        bool placed = KeepManager.Instance.PlaceKeepCard(target, instance);
        if (placed) user.RemoveCardFromHand(instance);
        return placed;
    }

    private static bool ProcessPlaceTrick(PlayerData user, CardInstance instance)
    {
        if (instance == null || !instance.CanTrick()) return false;
        bool placed = TrickManager.Instance.PlaceTrickCard(instance);
        if (placed) user.RemoveCardFromHand(instance);
        return placed;
    }

    private static bool ProcessOpenTrick(PlayerData user, CardInstance instance)
    {
        if (instance == null) return false;
        return TrickManager.Instance.OpenTrickCard(user, instance);
    }

    private static bool ProcessOpenPassive(PlayerData user)
    {
        Debug.Log($"{user.playerName}가 패시브를 오픈했습니다.");
        return true;
    }
}