using System.Collections.Generic;
using UnityEngine;

public class PlayerData
{
    // 기본 상태
    public string playerName;
    public int life = 100;
    public int actionPoint = 0;
    public int index;
    public bool skipStackDraw = false;
    // 카드 상태
    public List<CardInstance> hand = new List<CardInstance>();
    public CardInstance activeKeepCard;
    public CardInstance trickCard;
    // 지속 효과
    private readonly List<CardEffect> activeEffects = new();
    public IReadOnlyList<CardEffect> ActiveEffects => activeEffects;

    public PlayerData(string name, int idx)
    {
        playerName = name;
        index = idx;
    }

    public void DrawCard(int count = 1)
    {
        for (int i = 0; i < count; i++)
        {
            CardInstance drawn = DeckManager.Instance.Draw(this);
            if (drawn != null)
            {
                drawn.isFaceUp = true;
                hand.Add(drawn);
                EventManager.Instance.PublishCardDraw(this, drawn);
            }
        }
        EventManager.Instance.TriggerUIUpdate();
    }

    public void RemoveCardFromHand(CardInstance instance)
    {
        if (hand.Contains(instance))
        {
            hand.Remove(instance);
            EventManager.Instance.TriggerUIUpdate();
        }
    }

    public void TakeDamage(int amount)
    {
        if (amount <= 0) return;
        life -= amount;
        if (life < 0) life = 0;
        EventManager.Instance.TriggerUIUpdate();
    }

    public void GainActionPoint(int amount)
    {
        actionPoint += amount;
        EventManager.Instance.TriggerUIUpdate();
    }

    public void UseActionPoint()
    {
        actionPoint--;
        EventManager.Instance.TriggerUIUpdate();
    }

    // Trick 카드 관련
    public bool HasTrickCard() => trickCard != null;
    public void SetTrickCard(CardInstance instance) => trickCard = instance;
    public CardInstance GetTrickCard() => trickCard;
    public void RemoveTrickCard() => trickCard = null;

    // Keep 카드 관련
    public void AddKeepCard(CardInstance instance, bool isForced = false)
    {
        if (activeKeepCard != null)
        {
            // 기존 Keep 카드 해제 처리 필요
        }
        activeKeepCard = instance;
        instance.user = this;

        if (!isForced) actionPoint--;
        instance.ActivateEffects();
        EventManager.Instance.TriggerUIUpdate();
    }

    public void OnTurnStart()
    {
        if (activeKeepCard != null)
            activeKeepCard.ActivateEffects();
    }

    public void AddCardToHand(CardInstance instance)
    {
        if (instance == null) return;
        hand.Add(instance);
        instance.user = this;
        EventManager.Instance.TriggerUIUpdate();
    }

    public void RefreshUI()
    {
        EventManager.Instance.TriggerUIUpdate();
    }
}