public enum CardZone
{
    Hand,
    Keep,
    Trick,
    Passive,
    Stack,
    LowStack,
    Use,
    Discard
}

public enum ActionType
{
    UseCard,
    StackAttack,
    PlaceKeep,
    PlaceTrick,
    OpenTrick,
    DrawCard,
    OpenPassive
}

public enum TurnPhase
{
    None,
    Start,
    Action,
    End,
    Transition
}