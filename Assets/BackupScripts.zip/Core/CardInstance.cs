using UnityEngine;
using System;
using System.Collections.Generic;

#region Interfaces
public interface IImmediateEffect
{
    void Execute(PlayerData user, PlayerData target, CardInstance instance);
}
public interface IRegisterEffect
{
    void OnRegister(PlayerData user, CardInstance instance);
    void Deactivate(PlayerData user, CardInstance instance);
}
public interface IStackPowerModifier
{
    int ModifyPower(int currentPower, PlayerData user, CardInstance instance);
}
#endregion
public class CardInstance
{
    public PlayerData user;
    public Card origin;
    public bool isFaceUp = false;
    public CardZone currentZone;
    public PlayerData target;

    public List<Action> unregisterActions = new List<Action>();

    private bool isActivating = false;

    public CardInstance(Card card, PlayerData owner)
    {
        origin = card;
        user = owner;
        currentZone = CardZone.Hand;
    }
    #region Card Checks
    public bool CanUse() => origin != null && origin.HasCategory(CardCategory.Use) && currentZone == CardZone.Hand;
    public bool CanKeep() => origin != null && origin.HasCategory(CardCategory.Keep);
    public bool CanTrick() => origin != null && origin.HasCategory(CardCategory.Trick) && currentZone == CardZone.Hand;
    public bool CanStack()
    {
        if (origin == null) return false;
        if (currentZone != CardZone.Hand) return false;
        return origin.basePower != 0;
    }
    #endregion
    #region Effect Execution
    public void ExecuteImmediateEffects(PlayerData target)
    {
        if (origin.effects == null) return;
        foreach (var effect in origin.effects)
        {
            if (effect is IImmediateEffect immediate)
                immediate.Execute(user, target, this);
        }
    }
    public bool OpenTrick()
    {
        if (!CanTrick() || isFaceUp) return false;
        isFaceUp = true;
        ExecuteImmediateEffects(target);

        EventManager.Instance.TriggerUIUpdate();
        return true;
    }
    public void ActivateEffects()
    {
        if (origin.effects == null || isActivating) return;

        isActivating = true;
        foreach (var effect in origin.effects)
        {
            if (effect is IRegisterEffect register)
            {
                try
                {
                    register.OnRegister(user, this);
                }
                catch (Exception ex)
                {
                    Debug.LogError($"Error in OnRegister: {ex}");
                }
            }
        }
        isActivating = false;
        EventManager.Instance.TriggerUIUpdate();
    }
    public void DeactivateEffects()
    {
        foreach (var action in unregisterActions)
        {
            try { action.Invoke(); }
            catch (Exception ex) { Debug.LogError($"Error in unregister action: {ex}"); }
        }
        unregisterActions.Clear();

        if (origin.effects != null)
        {
            foreach (var effect in origin.effects)
            {
                if (effect is IRegisterEffect register)
                {
                    try { register.Deactivate(user, this); }
                    catch (Exception ex) { Debug.LogError($"Error in Deactivate: {ex}"); }
                }
            }
        }
        EventManager.Instance.TriggerUIUpdate();
    }
    #endregion
    #region Stack Power
    public int GetFinalPower()
    {
        int power = origin.basePower;
        if (origin.effects != null)
        {
            foreach (var effect in origin.effects)
            {
                if (effect is IStackPowerModifier modifier)
                    power = modifier.ModifyPower(power, user, this);
            }
        }
        return power;
    }
    #endregion
}