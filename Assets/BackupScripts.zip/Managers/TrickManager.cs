using UnityEngine;

public class TrickManager : MonoBehaviour
{
    public static TrickManager Instance;
    private void Awake() => Instance = this;

    public bool PlaceTrickCard(CardInstance instance)
    {
        if (instance == null || !instance.CanTrick()) return false;

        UIManager.Instance.MoveCardToZone(instance, CardZone.Trick);
        EventManager.Instance.TriggerUIUpdate();
        return true;
    }

    public bool OpenTrickCard(PlayerData user, CardInstance instance)
    {
        if (instance == null) return false;
        bool result = instance.OpenTrick();
        return result;
    }
}