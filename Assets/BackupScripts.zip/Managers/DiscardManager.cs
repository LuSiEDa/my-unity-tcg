using UnityEngine;
using System;
using System.Collections.Generic;
public class DiscardManager : MonoBehaviour
{
    public static DiscardManager Instance;

    public List<CardInstance> discardPile = new List<CardInstance>();
    public void Awake() => Instance = this;
    public void AddToDiscard(CardInstance instance)
    {
        if (instance == null) return;
        discardPile.Add(instance);
        UIManager.Instance.MoveCardToZone(instance, CardZone.Discard);
    }
    public void ClearDiscard()
    {
        discardPile.Clear();
        UIManager.Instance.ClearDiscardUI();
    }
}
