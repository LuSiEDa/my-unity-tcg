using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class TurnManager : MonoBehaviour
{
    public static TurnManager Instance;
    public List<PlayerData> players { get; private set; }
    public PlayerData localPlayer { get; private set; }
    public int currentTurnIndex = 0;
    public bool isClockwise = true;
    private TurnPhase currentPhase = TurnPhase.None;

    public PlayerData CurrentPlayer => players[currentTurnIndex];
    private bool initialized = false;

    void Awake()
    {
        if (Instance != null && Instance != this)
        {
            Destroy(gameObject);
            return;
        }
        Instance = this;
    }

    public void Initialize(List<PlayerData> createdPlayers, PlayerData local)
    {
        if (initialized) return;
        players = createdPlayers;
        localPlayer = local;
        currentTurnIndex = Random.Range(0, players.Count);
        initialized = true;
    }

    public void StartGame()
    {
        UIManager.Instance.CreateAllBoards(players, localPlayer);
        foreach (var player in players)
            player.DrawCard(players.Count);

        StartTurn();
    }

    public void StartTurn()
    {
        currentPhase = TurnPhase.Start;
        PlayerData player = CurrentPlayer;
        player.actionPoint = 1;

        EventManager.Instance.PublishTurnStart(player);
        EventManager.Instance.TriggerUIUpdate();
        UIManager.Instance.HighlightCurrentPlayer(player);

        currentPhase = TurnPhase.Action;

        if (player != localPlayer)
            StartCoroutine(CPUPlay(player));
    }

    public void PlayerAction(PlayerData user, ActionType action, CardInstance instance = null, PlayerData target = null)
    {
        if (!CanPlayerAct(user)) return;

        if (StackManager.Instance.IsStackOpen && action != ActionType.StackAttack)
            StackManager.Instance.ResolveNormalStack();

        if (action == ActionType.PlaceKeep && instance != null && target == null)
        {
            StartSelectingKeepTarget(user, instance);
            return;
        }

        ActionProcessor.Execute(user, action, instance, target);

        if (user.actionPoint <= 0)
            EndTurn();
    }

    private void StartSelectingKeepTarget(PlayerData user, CardInstance instance)
    {
        GameInputManager.Instance.StartSelectingPlayer((selectedPlayer) =>
        {
            ActionProcessor.Execute(user, ActionType.PlaceKeep, instance, selectedPlayer);
            UIMessage.Instance.Hide();
            if (user.actionPoint <= 0)
                EndTurn();
        });
    }

    private bool CanPlayerAct(PlayerData user)
    {
        return user == CurrentPlayer && currentPhase == TurnPhase.Action && user.actionPoint > 0;
    }

    public void EndTurn()
    {
        currentPhase = TurnPhase.End;
        EventManager.Instance.PublishTurnEnd(CurrentPlayer);

        currentPhase = TurnPhase.Transition;
        AdvanceTurnIndex();
        StartTurn();
    }

    private void AdvanceTurnIndex()
    {
        currentTurnIndex = isClockwise
            ? (currentTurnIndex + 1) % players.Count
            : (currentTurnIndex - 1 + players.Count) % players.Count;
    }

    public void GrantExtraTurn(PlayerData user)
    {
        if (user != CurrentPlayer) return;
        currentPhase = TurnPhase.Transition;
        StartTurn();
    }

    private IEnumerator CPUPlay(PlayerData player)
    {
        yield return new WaitForSeconds(1f);
        if (player.hand.Count > 0)
        {
            CardInstance card = player.hand[0];
            PlayerAction(player, ActionType.StackAttack, card);
        }
    }
}