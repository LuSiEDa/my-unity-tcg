using System.Collections;
using UnityEngine;

public class UseManager : MonoBehaviour
{
    public static UseManager Instance;
    private void Awake() => Instance = this;

    public bool UseCard(PlayerData user, CardInstance instance)
    {
        if (user == null || instance == null) return false;
        StartCoroutine(UseSequence(user, instance));
        return true;
    }

    private IEnumerator UseSequence(PlayerData user, CardInstance instance)
    {
        UIManager.Instance.MoveCardToZone(instance, CardZone.Use);
        EventManager.Instance.TriggerUIUpdate();
        yield return new WaitForSeconds(0.6f);

        instance.ExecuteImmediateEffects(instance.target);

        EventManager.Instance.TriggerUIUpdate();
        yield return new WaitForSeconds(0.4f);

        UIManager.Instance.MoveCardToZone(instance, CardZone.Discard);
        DiscardManager.Instance.AddToDiscard(instance);
        EventManager.Instance.TriggerUIUpdate();
    }
}