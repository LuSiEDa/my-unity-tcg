using UnityEngine;

public class KeepManager : MonoBehaviour
{
    public static KeepManager Instance;
    private void Awake() => Instance = this;

    public bool PlaceKeepCard(PlayerData target, CardInstance newCard)
    {
        if (target == null || newCard == null) return false;

        CardInstance oldCard = target.activeKeepCard;

        // 기존 Keep 카드 제거
        if (oldCard != null)
        {
            oldCard.DeactivateEffects();
            target.activeKeepCard = null;
            oldCard.user = target;
            DiscardManager.Instance.AddToDiscard(oldCard);
        }

        // 새 카드 설치
        target.activeKeepCard = newCard;
        newCard.user = target;
        UIManager.Instance.MoveCardToZone(newCard, CardZone.Keep);
        newCard.ActivateEffects();
        EventManager.Instance.TriggerUIUpdate();

        return true;
    }
}