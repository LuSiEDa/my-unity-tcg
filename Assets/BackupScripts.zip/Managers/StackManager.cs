using UnityEngine;
using System.Collections;
using System.Collections.Generic;

public class StackManager : MonoBehaviour
{
    public static StackManager Instance;

    public List<CardInstance> stack = new List<CardInstance>();
    public bool IsStackOpen => stack.Count > 0;

    public CardInstance topCard => IsStackOpen ? stack[stack.Count - 1] : null;
    public PlayerData topUser { get; private set; }

    private HashSet<PlayerData> lastStackHit = new HashSet<PlayerData>();
    private HashSet<PlayerData> cancelNextStackDrawFor = new HashSet<PlayerData>();

    private void Awake()
    {
        Instance = this;
    }

    // 스택 카드 진입
    public bool PlayStackCard(CardInstance instance)
    {
        if (instance == null || !instance.CanStack()) return false;

        instance.target = GetNextTarget(instance.user);
        instance.ActivateEffects();

        if (!IsStackOpen)
        {
            AddToStack(instance);
            return true;
        }

        int topPower = topCard.GetFinalPower();
        int newPower = instance.GetFinalPower();

        if (newPower >= topPower)
        {
            AddToStack(instance);
        }
        else
        {
            StartCoroutine(ResolveLowStackCoroutine(instance));
        }
        return true;
    }

    private void AddToStack(CardInstance instance)
    {
        stack.Add(instance);
        topUser = instance.user;
        UIManager.Instance.MoveCardToZone(instance, CardZone.Stack);
    }

    // 일반 스택 정산
    public void ResolveNormalStack()
    {
        if (!IsStackOpen) return;

        CardInstance top = topCard;
        if (top == null || top.target == null) return;

        int damage = top.GetFinalPower();
        top.target.TakeDamage(damage);

        ClearStackToDiscard();
    }

    // LowStack 처리
    private IEnumerator ResolveLowStackCoroutine(CardInstance lowInstance)
    {
        UIManager.Instance.MoveCardToZone(lowInstance, CardZone.LowStack);
        EventManager.Instance.TriggerUIUpdate();

        yield return new WaitForSeconds(0.6f);

        int topPower = topCard.GetFinalPower();
        int lowPower = lowInstance.GetFinalPower();
        int damage = Mathf.Max(0, topPower - lowPower);

        EventManager.Instance.PublishStackBeforeDamage(lowInstance.user, ref damage);

        if (lowInstance.origin.stackEffectType.HasFlag(StackEffectType.Defensive) &&
            lowInstance.origin.effects != null)
        {
            foreach (var effect in lowInstance.origin.effects)
                effect.Execute(lowInstance.user, lowInstance.target, lowInstance);
        }

        if (lowInstance.target != null)
            lowInstance.target.TakeDamage(damage);

        if (!cancelNextStackDrawFor.Contains(lowInstance.user))
            lowInstance.user.DrawCard(1);
        else
            cancelNextStackDrawFor.Remove(lowInstance.user);

        lastStackHit.Add(lowInstance.user);

        UIManager.Instance.MoveCardToZone(lowInstance, CardZone.Discard);
        DiscardManager.Instance.AddToDiscard(lowInstance);

        EventManager.Instance.PublishLowStackResolved(lowInstance.user, lowInstance);

        ClearStackToDiscard();
    }

    // 스택 해제 및 정리
    public void ClearStackToDiscard()
    {
        foreach (var instance in stack)
        {
            instance.DeactivateEffects();
            DiscardManager.Instance.AddToDiscard(instance);
        }
        stack.Clear();
        topUser = null;

        UIManager.Instance.MoveStackToDiscard(CardZone.Stack);
    }

    private PlayerData GetNextTarget(PlayerData user)
    {
        if (user == null || TurnManager.Instance.players == null || TurnManager.Instance.players.Count == 0)
            return null;

        List<PlayerData> players = TurnManager.Instance.players;
        int idx = user.index;

        if (TurnManager.Instance.isClockwise)
            idx = (idx + 1) % players.Count;
        else
            idx = (idx - 1 + players.Count) % players.Count;

        return players[idx];
    }
}