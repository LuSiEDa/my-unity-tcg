using UnityEngine;
using System;

public class EventManager : MonoBehaviour
{
    public static EventManager Instance;

    private void Awake()
    {
        if (Instance == null) Instance = this;
        else Destroy(gameObject);
    }

    // --- [방송 채널들] ---
    public event Action OnUIUpdateRequired;
    public event Action<PlayerData> OnTurnStarted;
    public event Action<PlayerData> OnTurnEnded;
    public event Action<PlayerData, CardInstance> OnCardDrawn;
    public event Action<PlayerData, CardInstance> OnCardReturnedToHand;
    // public event Action<CardInstance, PlayerData> OnCardUsed;
    // public event Action<CardInstance, PlayerData> OnCardStacked;
    // public event Action<CardInstance, PlayerData, PlayerData> OnCardKept;
    // public event Action<CardInstance, PlayerData> OnTrickOpened;
    
    public delegate void DamageCalculationHandler(PlayerData target, ref int damage);
    public event DamageCalculationHandler OnBeforeStackDamageApplied;

    public event Action<PlayerData, CardInstance> OnLowStackResolved;

    // --- [방송 송출 버튼들] ---
    public void TriggerUIUpdate() => OnUIUpdateRequired?.Invoke();
    public void PublishTurnStart(PlayerData user) => OnTurnStarted?.Invoke(user);
    public void PublishTurnEnd(PlayerData user) => OnTurnEnded?.Invoke(user);
    public void PublishCardDraw(PlayerData user, CardInstance instance) => OnCardDrawn?.Invoke(user, instance);
    public void PublishCardReturn(PlayerData user, CardInstance instance) => OnCardReturnedToHand?.Invoke(user, instance);
    
    // 데미지 방송 송출! (StackManager가 이 버튼을 누를 거예요)
    public void PublishStackBeforeDamage(PlayerData target, ref int damage) 
        => OnBeforeStackDamageApplied?.Invoke(target, ref damage);

    public void PublishLowStackResolved(PlayerData user, CardInstance instance)
        => OnLowStackResolved?.Invoke(user, instance);
}
