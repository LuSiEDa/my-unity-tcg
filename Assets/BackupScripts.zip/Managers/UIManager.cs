using System.Collections.Generic;
using UnityEngine;

public class UIManager : MonoBehaviour
{
    public static UIManager Instance;
    [Header("Prefabs")]
    [SerializeField] 
    private GameObject myBoardPrefab;
    [SerializeField] 
    private GameObject enemyBoardPrefab;
    [SerializeField]
    private GameObject cardPrefab; //카드 Ui 프리팹

    [Header("Parents")]
    [SerializeField]
    private Transform myBoardArea;
    [SerializeField]
    private Transform topPlayersArea;
    [Header("Global Zones")]
    [SerializeField] private Transform stackZone;
    [SerializeField] private Transform lowStackZone;
    
    [SerializeField] private Transform useZone;
    [SerializeField] private Transform discardZone;

    private PlayerUI myUI;
    private List<PlayerUI> enemySlots = new List<PlayerUI>();
    private List<GameObject> stackCardUIs = new List<GameObject>();
    private List<GameObject> discardUIs = new List<GameObject>();
    private Dictionary<CardInstance, CardUI> cardUIMap = new();
    void Awake()
    {
        Instance = this;
    }
    // 전체 UI 초기화 메인 함수
    public void CreateAllBoards(List<PlayerData> players, PlayerData localPlayer)
    {
        ClearAll();

        CreateMyBoard(localPlayer);
        CreateEnemyBoards(players, localPlayer);
    }
    // 내 UI 생성
    void CreateMyBoard(PlayerData localPlayer)
    {
        GameObject board = Instantiate(myBoardPrefab, myBoardArea);
        RectTransform rect = board.GetComponent<RectTransform>();
        rect.anchoredPosition = Vector2.zero;

        myUI = board.GetComponent<PlayerUI>();
        myUI.Setup(localPlayer);

        GameInputManager.Instance.RegisterPlayerUI(myUI);
    }
    // 상대방 UI 생성
    public void CreateEnemyBoards(List<PlayerData> players, PlayerData localPlayer)
    {
        foreach (var player in players)
        {
            if (player == localPlayer)
                continue;

        GameObject slot = Instantiate(enemyBoardPrefab, topPlayersArea);
        RectTransform rect = slot.GetComponent<RectTransform>();
        rect.anchoredPosition = Vector2.zero;

        PlayerUI ui = slot.GetComponent<PlayerUI>();
        ui.Setup(player);

        GameInputManager.Instance.RegisterPlayerUI(ui);
        
        enemySlots.Add(ui);
        }
    }
    // UI 오브젝트 파괴
    void ClearAll()
    {
        if (myUI != null)
            Destroy(myUI.gameObject);
        
        foreach (var ui in enemySlots)
        {
            if (ui != null)
                Destroy(ui.gameObject);
        }
        enemySlots.Clear();
        foreach (var pair in cardUIMap)
        {
            if (pair.Value != null)
                Destroy(pair.Value.gameObject);
        }

        cardUIMap.Clear();
    }
    public void MoveCardToZone(CardInstance instance, CardZone zone)
    {
        if (instance == null) return;

        instance.currentZone = zone;

        PlayerData user = instance.user; 
        Transform parent = GetZoneTransform(zone, user);
        if (parent == null) return;

        CardUI ui = GetOrCreateUI(instance);

        ui.transform.SetParent(parent, false);
        ui.UpdateVisual(GetSizeByZone(zone, user));

        RectTransform rt = ui.GetComponent<RectTransform>();
        if (rt != null)
        {
            rt.anchoredPosition = Vector2.zero;
            rt.localRotation = Quaternion.identity;
            rt.localScale = Vector3.one;
        }
    }
    Transform GetZoneTransform(CardZone zone, PlayerData user)
    {
        switch (zone)
        {
            case CardZone.Stack:
                return stackZone;
            case CardZone.LowStack: 
                return lowStackZone;
            case CardZone.Use: 
                return useZone;
            case CardZone.Discard:
                return discardZone;
        }

        if (user == null)
            return null;

        if (myUI != null && user == myUI.Data)
            return myUI.GetZone(zone);

        foreach (var ui in enemySlots)
            if (ui.Data == user)
                return ui.GetZone(zone);

        return null;           
    }
    CardUI GetOrCreateUI(CardInstance instance)
    {
        if (cardUIMap.TryGetValue(instance, out var existingUI))
            return existingUI;
        
        GameObject obj = Instantiate(cardPrefab);
        CardUI ui = obj.GetComponent<CardUI>();
        ui.Setup(instance, true, GetSizeByZone(instance.currentZone, instance.user));

        cardUIMap.Add(instance, ui);
        return ui;
    }
    private CardUI.CardSize GetSizeByZone(CardZone zone, PlayerData user)
    {
        // 상대 보드의 Keep은 S
        if (zone == CardZone.Keep)
        {
            if (user != TurnManager.Instance.localPlayer)
                return CardUI.CardSize.S;
            return CardUI.CardSize.M;
        }
        switch (zone)
        {
            case CardZone.Discard:
            case CardZone.LowStack:
                return CardUI.CardSize.S;

            case CardZone.Stack:
            case CardZone.Hand:
            case CardZone.Use:
                return CardUI.CardSize.M;

            default:
                return CardUI.CardSize.M;
        }
    }
    public void MoveStackToDiscard(CardZone fromZone)
    {
        if (discardZone == null) return;

        foreach (var pair in cardUIMap)
        {
            if (pair.Key.currentZone == fromZone)
                MoveCardToZone(pair.Key, CardZone.Discard);
        }
    }

    public void ClearStackUI()
    {
        foreach (var obj in stackCardUIs)
        {
            if (obj != null)
                Destroy(obj);
        }
        stackCardUIs.Clear();
    }
    public void ClearDiscardUI()
    {
        foreach (var obj in discardUIs)
        {
            if (obj != null)
                Destroy(obj);
        }
        discardUIs.Clear();
    }
    // 턴 플레이어 강조
    public void HighlightCurrentPlayer(PlayerData currentPlayer)
    {
        if (myUI != null)
            myUI.SetHighlight(myUI.Data == currentPlayer);

        foreach (var ui in enemySlots)
        {
            ui.SetHighlight(ui.Data == currentPlayer);
        }
    }
    // 전체 강제 새로고침 (전체를 다 돌기 때문에 비용이 든다.)
    public void RefreshAllUI()
    {
        if (myUI != null)
            myUI.Refresh();

        foreach (var ui in enemySlots)
        {
            ui.Refresh();
        }
    }
}
