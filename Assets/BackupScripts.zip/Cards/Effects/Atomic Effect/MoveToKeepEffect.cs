using UnityEngine;

[CreateAssetMenu(fileName = "MoveToKeepEffect", menuName = "CardEffects/MoveToKeepEffect")]
public class MoveToKeepEffect : CardEffect
{
    // 인스펙터에서 체크 가능. true면 행동력 소모 없이 이동.
    public bool isForced = true; 

    // ★중요: 아래 Execute 함수는 이 파일 안에 딱 '하나'만 있어야 합니다!
    public override void Execute(PlayerData user, PlayerData target = null, CardInstance instance = null)
    {
        if (instance != null && user != null)
        {
            // 스택에서 이 카드를 먼저 지움 (중복 방지)
            if (StackManager.Instance.stack.Contains(instance))
            {
                StackManager.Instance.stack.Remove(instance);
            }
            // 상대플레이어의 지속 카드로 이동
            target.AddKeepCard(instance, isForced);
            Debug.Log($"{instance.origin.cardName}이(가) 스택에서 빠져나와 지속물로 이동했습니다.");
        }
    }
}