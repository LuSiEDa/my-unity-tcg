using UnityEngine;

[CreateAssetMenu(fileName = "EmpressCaptureEffect", menuName = "CardEffects/EmpressCapture")]
public class EmpressCaptureEffect : CardEffect
{
    public override void Execute(PlayerData user, PlayerData target = null, CardInstance instance = null)
    {
        if (user == null || instance == null) return;

        // 1. 플레이어에게 "스택 드로우 스킵" 신호를 보냅니다.
        // PlayerData에 bool skipStackDraw 같은 변수가 있다고 가정합니다.
        instance.DeactivateEffects();
        target.skipStackDraw = true;

        // 2. 스택 매니저에서 이 카드(엠프리스)를 제거하여 버림미로 가지 않게 방지
        if (StackManager.Instance.stack.Contains(instance))
        {
            StackManager.Instance.stack.Remove(instance);
        }

        // 3. 덱에서 뽑는 대신 이 카드를 패에 넣음
        target.AddCardToHand(instance);
        instance.ActivateEffects();
        EventManager.Instance.PublishCardReturn(target, instance);

        Debug.Log($"{user.playerName}이(가) 스택 드로우를 포기하고 엠프리스를 회수했습니다.");
    }
}
