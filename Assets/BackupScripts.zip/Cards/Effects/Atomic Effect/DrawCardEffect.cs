using UnityEngine;

[CreateAssetMenu(fileName = "DrawCardEffect", menuName = "CardEffects/DrawCardEffect")]
public class DrawCardEffect : CardEffect
{
    public int amount = 1;

    public override void Execute(PlayerData user, PlayerData target = null, CardInstance instance = null)
    {
        user.DrawCard(amount);
    }
}
