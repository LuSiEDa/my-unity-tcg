using UnityEngine;
using System.Collections.Generic; // List를 쓰기 위해 필요
using System.Linq;               // [추가] Last()를 쓰기 위해 반드시 필요!

[CreateAssetMenu(fileName = "ConsumePersistentEffect", menuName = "CardEffects/ConsumePersistentEffect")]
public class ConsumePersistentEffect : CardEffect
{
    public override void Execute(PlayerData user, PlayerData target = null, CardInstance instance = null)
    {
        if (target == null || target.activeKeepCard == null)
        {
            Debug.LogWarning("대상 플레이어나 카드가 지정되지 않음");
            return;
        }
        // 1. 대상의 지속 카드 중 가장 최근에 깔린 카드를 선택 (혹은 랜덤)
        CardInstance targetCard = target.activeKeepCard;

        // 2. 데미지 계산 (카드의 원본 파워 가져오기)
        int damageValue = targetCard.origin.basePower;

        // 3. 지속 카드 제거 및 버림미로 이동
        target.activeKeepCard = null;
        DiscardManager.Instance.AddToDiscard(targetCard);

        // 4. 데미지 입히기
        target.TakeDamage(damageValue);

        Debug.Log($"{target.playerName}의 {targetCard.origin.cardName}을(를) 파괴하고 {damageValue} 데미지를 입혔습니다!");
    }
}
