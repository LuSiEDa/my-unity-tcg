using UnityEngine;
using System;

[CreateAssetMenu(fileName = "PeriodicDamageEffect", menuName = "CardEffects/PeriodicDamageEffect")]
public class PeriodicDamageEffect : CardEffect
{
    public int damageAmount = 10;

    public override void OnRegister(PlayerData user, CardInstance instance)
    {
        Action<PlayerData> handler = (activePlayer) =>
        {   
            // 현재 턴을 시작하는 사람이 이 카드의 주인이라면 데미지!
            if (activePlayer == user) activePlayer.TakeDamage(damageAmount);
        };
        EventManager.Instance.OnTurnStarted += handler;
        instance.unregisterActions.Add(() =>
        {
            EventManager.Instance.OnTurnStarted -= handler;
        });
    }
    public override void Execute(PlayerData user, PlayerData target = null, CardInstance instance = null)
    {
        
    }
}
