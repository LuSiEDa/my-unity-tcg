using UnityEngine;
using System;
using System.Collections.Generic;

[CreateAssetMenu(menuName = "CardEffects/TriggerContainer")]
public class TriggerContainer : CardEffect
{
    public enum TriggerType { OnBeforeDamage, OnLowStackResolved }
    public TriggerType triggerType;
    public List<CardEffect> effectsToRun;

    public override void OnRegister(PlayerData user, CardInstance instance)
    {
        switch(triggerType)
        {
            case TriggerType.OnBeforeDamage:
                EventManager.DamageCalculationHandler handler = (PlayerData target, ref int damage) =>
                {
                    if(target == user)
                    {
                        foreach(var e in effectsToRun)
                            e.ModifyDamage(ref damage); // ModifyDamage 사용
                    }
                };
                EventManager.Instance.OnBeforeStackDamageApplied += handler;
                instance.unregisterActions.Add(() => EventManager.Instance.OnBeforeStackDamageApplied -= handler);
                break;

            case TriggerType.OnLowStackResolved:
                Action<PlayerData, CardInstance> lowHandler = (target, resolvedCard) =>
                {
                    if(target == user && resolvedCard == instance)
                    {
                        foreach(var e in effectsToRun)
                            e.Execute(user, null, instance);
                    }
                };
                EventManager.Instance.OnLowStackResolved += lowHandler;
                instance.unregisterActions.Add(() => EventManager.Instance.OnLowStackResolved -= lowHandler);
                break;
        }
    }

    public override void Execute(PlayerData user, PlayerData target = null,  CardInstance instance = null)
    {
    }

}
